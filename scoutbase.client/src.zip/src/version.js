// version.js
export const appVersion = {
	version: '0.8.8',

};